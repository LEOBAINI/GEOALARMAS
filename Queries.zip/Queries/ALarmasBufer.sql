SELECT 
et.eventype_id, et.descr as 'tipo_eventos',ev.descr
,CONVERT(varchar(24),sas.alarm_date) alarm_date
,si.udf3 as 'contrato', si.longitude,si.latitude,si.zip_code, si.city_name, si.state_id,  LEFT(si.zip_code,2) as'geo_code'
,js.job_no, js.jobtype_id,js.jobres_id --si se ha avisado al acuda

FROM system_alarm_status sas with (nolock)
inner join event ev on sas.alarm_event_id=ev.event_id and ev.eventype_id like 'AL%'
inner join event_type et on et.eventype_id=ev.eventype_id
inner join system sy on sas.system_no=sy.system_no
inner join site si on si.site_no=sy.site_no 
		and si.udf3 is not null --se quitan los q no tienen contrato
		AND si.sitetype_id NOT IN ('VC', 'VF', 'VO', 'VP') -- NO vehiculos	

Left join job_summary js on sas.alarminc_no=js.alarminc_no and js.jobstat_id not in ('L') --job no cancel
where si.latitude is not null and si.longitude is not null
--and si.state_id not in ('TEN','LP') --sin canarias
and sas.alarm_date >=CAST(getdate() AS date)



