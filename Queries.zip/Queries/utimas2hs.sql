SELECT 
et.eventype_id, et.descr as 'tipo_eventos',ev.descr
,ai.alarm_server_date
,si.udf3 as 'contrato', si.longitude,si.latitude,si.zip_code, si.city_name, si.state_id,  LEFT(si.zip_code,2) as'geo_code'

,js.job_no, js.jobtype_id,js.jobres_id, --si se ha avisado al acuda
case 

when ai.alarm_server_date >= dateadd(hh,-1,getdate()) then 'green' --dentro de la ultima hora
when ai.alarm_server_date < dateadd(hh,-1,getdate()) THEN 'orange' -- mas antigua que x hs

ELSE 'cyan' 
end as color


FROM alarm_incident ai with (nolock)
inner join event ev on ai.event_id=ev.event_id and ev.eventype_id like 'AL%'
inner join event_type et on et.eventype_id=ev.eventype_id
inner join system sy on ai.system_no=sy.system_no
inner join site si on si.site_no=sy.site_no 
		and si.udf3 is not null --se quitan los q no tienen contrato
		AND si.sitetype_id NOT IN ('VC', 'VF', 'VO', 'VP') -- NO vehiculos	

Left join job_summary js on ai.alarminc_no=js.alarminc_no and js.jobstat_id not in ('L') --job no cancel


where ai.alarm_server_date >= CAST(getdate() AS date)
order by alarm_server_date
